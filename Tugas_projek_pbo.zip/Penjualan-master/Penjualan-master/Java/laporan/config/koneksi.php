<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "penjualan";

$con = mysqli_connect($host, $user, $pass, $db);

 

?>